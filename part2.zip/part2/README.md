This folder contains the files for part 2.

- Use `npm install` to install necessary modules.
- Start a MySQL server.
- Use `npm start` to run it.